#!/bin/bash

# Name: uScanner (Username Scanner Tool)
# GitHub: https://github.com/TrollSkull/uScanner
# Version: v1.0

# Scanning up to 12 social networks!

trap 'echo "";ctrl_c;exit 1' 2
source $HOME/uScanner/lib/variables.sh

function print_banner() {
    clear
    echo -e ${B}"       ____                                  "
    echo -e ${B}" __ __/ __/______ ____  ___  ___ ____        " 
    echo -e ${B}"/ // /\ \/ __/ _  / _ \/ _ \/ -_) __/        "
    echo -e ${B}"\_,_/___/\__/\_,_/_//_/_//_/\__/_/   ${W}v1.0"
    echo 
}

function ctrl_c() {
    print_banner
    echo -e ${Y}"[uScanner] ${W}Keyboard interrupt detected, exiting."
}

function depencencies() {

    DEPENDENCIES=(curl python)

    print_banner
    echo -e "${W}[i] Press CTRL+C to stop the script.\n"
    echo -e ${B}"[uScanner] ${W}Checking dependencies..."

    if [ "${SYSTEM}" == "Android" ]; then
        for PROGRAM in "${DEPENDENCIES[@]}"; do

            test -f data/data/com.termux/files/usr/bin/$PROGRAM

            if [ "$(echo $?)" == "0" ]; then
                echo -e "${B}${PROGRAM} ${W}is installed."

            else
                echo -e "${Y}$PROGRAM ${W}is not installed."
                echo -e "Installing ${B}${PROGRAM}${W}..."
                apt-get install $PROGRAM -y > /dev/null 2>&1

            fi; sleep 2
        done
    else
        for PROGRAM in "${DEPENDENCIES[@]}"; do

            test -f /usr/bin/$PROGRAM

            if [ "$(echo $?)" == "0" ]; then
                echo -e "${B}${PROGRAM} ${W}is installed."

            else
                echo -e "${Y}$PROGRAM ${W}is not installed."
                echo -e "Installing ${B}${PROGRAM}${W}..."
                apt-get install $PROGRAM -y > /dev/null 2>&1

            fi; sleep 2
        done
    fi
}

function scan_username() { # más manejo de error en el grep

    print_banner

    SOCIALMEDIA=(instagram facebook youtube twitter github pinterest soundcloud patreon canva codecademy bitbucket mixcloud)
    declare -i FOUND=0

    echo -e "Checking username ${B}${USERNAME}${W}..."
    echo

    for SOCIAL in "${SOCIALMEDIA[@]}"; do

        check=$(curl -s "https://www.${SOCIAL}.com/${USERNAME}" -L -H "Accept-Language: en" | grep -o '404 Not Found'; echo $?)
        echo -ne "Checking https://www.${SOCIAL}.com/${USERNAME}... "

        if [[ $check == *'0'* ]]; then
            echo -e ${Y}"[Not Found!]"

        else
            echo -e ${GRE}"[Found!]"
            FOUND=$FOUND+1
        fi

    done

    echo
    echo -e ${B}"[uScanner] ${W}Username ${USERNAME} found on ${FOUND} pages."
}

function save_file() { # testear

    cd $HOME/uScanner/usernames; echo -e "${B}"; ls; echo -e "${W}"

    echo -ne ${GRE}"[uScanner] ${W}What file do you want to save? ${Y}(File name): ${W}"
    read SAVEDFILE

    if [[ -e $SAVEDFILE.txt ]]; then

        mv ${SAVEDFILE}.txt $EXTERNAL_STORAGE
        echo -e ${B}"[uScanner] ${W}Saved:${B} ${SAVEDFILE}.txt ${W}in${B} $EXTERNAL_STORAGE"
        exit

    else

        echo -e ${Y}"[uScanner] ${W}Could not locate file." 
        exit

    fi

    exit
}

if [ -z "$1" ]; then

    print_banner
    echo -ne ${GRE}"[uScanner] ${W}Input username: "
    read USERNAME
    clear

elif [ "$1" == "--help" ]||[ "$1" == "-h" ]; then
    print_banner
    echo "Usage: ./uscanner.sh [username] or [-h] [-s] [-a] [-u]"
    echo
    echo "    -h, --help              Print this help menu"
    echo "    -s, --save              Save the .txt file in the storage"
    echo "    -a, --about             Print information about this program"
    echo "    -u, --update            Update this tool automatically"
    echo "        --uninstall         Uninstall the tool"
    echo
    echo "Report bugs to (t.me/TrollSkull)"
    echo
    exit

elif [ "$1" == "--save" ]||[ "$1" == "-s" ]; then

    print_banner
    save_file
    exit

elif [ "$1" == "--update" ]||[ "$1" == "-u" ]; then

    cd $HOME
    rm -rf "uScanner"

    git clone https://github.com/TrollSkull/uScanner
    cd $HOME/uScanner

    chmod 777 uscanner.sh

    print_banner
    echo -e ${GRE}"[uScanner] ${W}The tool has been successfully updated."
    exit

elif [ "$1" == "--about" ]||[ "$1" == "-a" ]; then
    print_banner
    echo "Name:     uScanner"
    echo "Author:   TrollSkull"
    echo "Version:  v1.0"
    echo
    echo "Contact:   t.me/TrollSkull"
    echo "Follow me: https://github.com/TrollSkull"
    echo
    exit

elif [ "$1" == "--uninstall" ]; then

    print_banner
    echo -e ${B}"[uScanner] ${W}Uninstalling..."

    rm -rf "$HOME/uScanner"

    echo -e ${GRE}"[uScanner] ${W}The tool has been uninstalled."
    exit
    
else # ver si puedo hacer lo del scan múltiple
    username=$1
fi

depencencies
scan_username