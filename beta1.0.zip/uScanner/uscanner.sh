#!/bin/bash

# Name: uScanner (Username Scanner Tool)
# GitHub: https://github.com/TrollSkull/uScanner
# Version: v1.0 Beta

trap 'echo "";ctrl_c;exit 1' 2
source $HOME/uScanner/lib/variables.sh
MAIN="MAIN"

function print_banner() {
    clear
    echo -e ${B}"       ____                                  "
    echo -e ${B}" __ __/ __/______ ____  ___  ___ ____        " 
    echo -e ${B}"/ // /\ \/ __/ _  / _ \/ _ \/ -_) __/        "
    echo -e ${B}"\_,_/___/\__/\_,_/_//_/_//_/\__/_/   ${W}v1.0"
    echo 
}

function ctrl_c() {
    print_banner
    echo -e ${Y}"[uScanner] ${W}Keyboard interrupt detected, exiting."; exit
}

function depencencies() {

    DEPENDENCIES=(curl python)

    print_banner
    echo -e "${W}[i] Press CTRL+C to stop the script.\n"
    echo -e ${B}"[uScanner] ${W}Checking dependencies..."

    if [ "${SYSTEM}" == "Android" ]; then
        for PROGRAM in "${DEPENDENCIES[@]}"; do

            test -f data/data/com.termux/files/usr/bin/$PROGRAM

            if [ "$(echo $?)" == "0" ]; then
                echo -e "${B}${PROGRAM} ${W}is installed."

            else
                echo -e "${Y}$PROGRAM ${W}is not installed."
                echo -e "Installing ${B}${PROGRAM}${W}..."
                apt-get install $PROGRAM -y > /dev/null 2>&1

            fi; sleep 2
        done
    else
        for PROGRAM in "${DEPENDENCIES[@]}"; do

            test -f /usr/bin/$PROGRAM

            if [ "$(echo $?)" == "0" ]; then
                echo -e "${B}${PROGRAM} ${W}is installed."

            else
                echo -e "${Y}$PROGRAM ${W}is not installed."
                echo -e "Installing ${B}${PROGRAM}${W}..."
                apt-get install $PROGRAM -y > /dev/null 2>&1

            fi; sleep 2
        done
    fi
}

function scan_username() {

    print_banner

    SOCIALMEDIA=(instagram facebook youtube twitter github pinterest soundcloud patreon canva codecademy bitbucket mixcloud)
    declare -i FOUND=0

    echo -e ${B}"[uScanner] ${W}Searching username ${B}${USERNAME}${W} on..."
    echo

    for SOCIAL in "${SOCIALMEDIA[@]}"; do
       
        CHECK=$(curl -s "https://www.${SOCIAL}.com/${USERNAME}" -L -H "Accept-Language: en" | grep -owie '404 Not Found' -owie 'Page not found' -owie 'This page is not available' -owie 'This account does not exist' -owie 'HTTP/2 404'; echo $?)
        echo -ne "Checking https://www.${SOCIAL}.com/${USERNAME}... "

        if [[ $CHECK == *'0'* ]]; then
            echo -e ${Y}"[Not Found!]${W}"

        else
            echo -e ${GRE}"[Found!]${W}"
            FOUND=$FOUND+1
        fi

    done

    echo
    echo -e ${B}"[uScanner] ${W}Username ${USERNAME} found on ${FOUND} pages."
}

function save_file() {

    echo -e ${B}"[uScanner] ${W}These are your .txt files: "
    cd $HOME/uScanner/usernames; echo -e "${B}"; ls; echo -e "${W}"

    echo -ne ${B}"[uScanner] ${W}What file do you want to save? ${Y}(File name): ${W}"; read SAVEDFILE

    if [[ -e $SAVEDFILE.txt ]]; then
        mv ${SAVEDFILE}.txt $EXTERNAL_STORAGE
        echo -e ${GRE}"[uScanner] ${W}Saved:${B} ${SAVEDFILE}.txt ${W}in${B} $EXTERNAL_STORAGE"
        exit

    else
        echo -e ${Y}"[uScanner] ${W}Could not locate file." 
        exit

    fi

    exit
}

function main() {
    depencencies
    scan_username
}

if [ -z "$1" ]; then

    print_banner
    echo -ne ${GRE}"[uScanner] ${W}Input username: "; read USERNAME
    clear

elif [ "$1" == "--help" ]||[ "$1" == "-h" ]; then

    print_banner
    echo -e ${W}"Usage: ./uscanner.sh [username] or [-h] [-s] [-a] [-u]"
    echo
    echo -e ${B}"    -h, --help              ${W}Print this help menu"
    echo -e ${B}"    -s, --save              ${W}Save the .txt file in the storage"
    echo -e ${B}"    -a, --about             ${W}Print information about this program"
    echo -e ${B}"    -u, --update            ${W}Update this tool automatically"
    echo -e ${B}"        --uninstall         ${W}Uninstall the tool"
    echo
    echo -e ${W}"Report bugs to (t.me/TrollSkull)"
    echo; exit

elif [ "$1" == "--save" ]||[ "$1" == "-s" ]; then

    print_banner; save_file; exit

elif [ "$1" == "--update" ]||[ "$1" == "-u" ]; then

    print_banner
    echo -e ${B}"[uScanner] ${W}Updating tool..."

    cd $HOME; rm -rf "uScanner"
    git clone https://github.com/TrollSkull/uScanner > /dev/null 2>&1
    cd $HOME/uScanner; chmod 777 uscanner.sh

    print_banner
    echo -e ${GRE}"[uScanner] ${W}The tool has been successfully updated."; exit

elif [ "$1" == "--about" ]||[ "$1" == "-a" ]; then

    print_banner
    echo -e ${GRE}"Name:     ${W}uScanner"
    echo -e ${GRE}"Author:   ${W}TrollSkull"
    echo -e ${GRE}"Version:  ${W}v1.0"
    echo
    echo -e ${GRE}"Contact:   ${W}t.me/TrollSkull"
    echo -e ${GRE}"Follow me: ${W}https://github.com/TrollSkull"
    echo; exit

elif [ "$1" == "--uninstall" ]; then

    print_banner
    echo -e ${B}"[uScanner] ${W}Uninstalling..."

    rm -rf "$HOME/uScanner"

    echo -e ${GRE}"[uScanner] ${W}The tool has been uninstalled."; exit
    
else
    USERNAME=$1
fi

if [ $MAIN == "MAIN" ]; then
    main()
fi