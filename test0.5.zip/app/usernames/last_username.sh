#!/bin/bash
export last_username=''