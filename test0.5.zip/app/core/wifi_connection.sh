#!/bin/bash
export wifi=''